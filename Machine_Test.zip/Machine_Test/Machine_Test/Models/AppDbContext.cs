﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace Machine_Test.Models
{
    public class AppDbContext : DbContext
    {
        // Constructor to initialize DbContext with options
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        // DbSets representing tables in the database
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
    }
}
